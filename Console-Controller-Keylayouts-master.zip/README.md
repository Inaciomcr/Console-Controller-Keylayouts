# Console Controller Keylayouts [Magisk]

Adds keylayout files for console controllers for use on Android devices. 

Currently supports Xbox 360, Xbox One and Xbox One S controllers.

[Support](http://forum.xda-developers.com/apps/magisk/magisk-console-controller-keylayouts-t3474174)

[Donate](https://www.paypal.me/BenjaminKatkin)
